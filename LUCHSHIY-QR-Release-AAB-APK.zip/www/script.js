// ========================================
// LUCHSHIY QR
// SCRIPT.JS — BLOCK 1
// BASE + STATE + STORAGE
// ========================================

const $ = selector =>
  document.querySelector(selector);

const $$ = selector =>
  document.querySelectorAll(selector);


// ========================================
// DOM
// ========================================

const generateButton =
  $("#generateButton");

const qrResult =
  $("#qrResult");

const qrCanvas =
  $("#qrCanvas");

const closeResult =
  $("#closeResult");

const qrText =
  $("#qrText");

const qrUrl =
  $("#qrUrl");

const qrPhone =
  $("#qrPhone");

const qrEmail =
  $("#qrEmail");

const emailSubject =
  $("#emailSubject");

const contactName =
  $("#contactName");

const contactPhone =
  $("#contactPhone");

const wifiName =
  $("#wifiName");

const wifiPassword =
  $("#wifiPassword");

const wifiSecurity =
  $("#wifiSecurity");

const textCount =
  $("#textCount");

const toast =
  $("#toast");

const toastText =
  $("#toastText");

const toastIcon =
  $("#toastIcon");


// ========================================
// STATE
// ========================================

const state = {

  currentType: "text",

  currentData: "",

  currentQR: null,

  history: [],

  favorites: [],

  qrSettings: {

    size: 512,

    foreground: "#000000",

    background: "#ffffff",

    margin: 2

  }

};


// ========================================
// INPUT AREAS
// ========================================

const inputAreas = {

  text:
    $("#textInputArea"),

  url:
    $("#urlInputArea"),

  wifi:
    $("#wifiInputArea"),

  contact:
    $("#contactInputArea"),

  email:
    $("#emailInputArea"),

  phone:
    $("#phoneInputArea")

};


// ========================================
// TOAST
// ========================================

function showToast(
  message,
  icon = "✓"
) {

  if (!toast) return;

  toastText.textContent =
    message;

  toastIcon.textContent =
    icon;

  toast.classList.add("show");

  clearTimeout(
    window.qrToastTimer
  );

  window.qrToastTimer =
    setTimeout(() => {

      toast.classList.remove(
        "show"
      );

    }, 2400);
}


// ========================================
// STORAGE KEYS
// ========================================

const STORAGE = {

  history:
    "luchshiyQRHistory",

  favorites:
    "luchshiyQRFavorites",

  settings:
    "luchshiyQRSettings"

};


// ========================================
// LOAD STORAGE
// ========================================

function loadStorage() {

  try {

    const history =
      JSON.parse(
        localStorage.getItem(
          STORAGE.history
        ) || "[]"
      );

    const favorites =
      JSON.parse(
        localStorage.getItem(
          STORAGE.favorites
        ) || "[]"
      );

    const settings =
      JSON.parse(
        localStorage.getItem(
          STORAGE.settings
        ) || "null"
      );

    if (
      Array.isArray(history)
    ) {
      state.history =
        history;
    }

    if (
      Array.isArray(favorites)
    ) {
      state.favorites =
        favorites;
    }

    if (
      settings &&
      typeof settings ===
        "object"
    ) {

      state.qrSettings = {

        ...state.qrSettings,

        ...settings

      };

    }

  } catch (error) {

    console.warn(
      "Storage error:",
      error
    );

  }

}


// ========================================
// SAVE STORAGE
// ========================================

function saveHistory() {

  localStorage.setItem(
    STORAGE.history,
    JSON.stringify(
      state.history
    )
  );

}


function saveFavorites() {

  localStorage.setItem(
    STORAGE.favorites,
    JSON.stringify(
      state.favorites
    )
  );

}


function saveSettings() {

  localStorage.setItem(
    STORAGE.settings,
    JSON.stringify(
      state.qrSettings
    )
  );

}


// ========================================
// ESCAPE HTML
// ========================================

function escapeHTML(value) {

  return String(value)

    .replace(
      /&/g,
      "&amp;"
    )

    .replace(
      /</g,
      "&lt;"
    )

    .replace(
      />/g,
      "&gt;"
    )

    .replace(
      /"/g,
      "&quot;"
    )

    .replace(
      /'/g,
      "&#039;"
    );

}


// ========================================
// TEXT COUNTER
// ========================================

function updateTextCount() {

  if (!qrText || !textCount) {
    return;
  }

  textCount.textContent =
    `${qrText.value.length} / 2000`;

}


qrText?.addEventListener(
  "input",
  updateTextCount
);


// ========================================
// TYPE SWITCHING
// ========================================

function setQRType(type) {

  if (!inputAreas[type]) {
    return;
  }

  state.currentType =
    type;

  $$(".type-button")
    .forEach(button => {

      button.classList.toggle(
        "active",
        button.dataset.type ===
          type
      );

    });

  Object.values(
    inputAreas
  ).forEach(area => {

    area?.classList.add(
      "hidden"
    );

  });

  inputAreas[type]
    ?.classList.remove(
      "hidden"
    );

}


// ========================================
// TYPE BUTTONS
// ========================================

$$(".type-button")
  .forEach(button => {

    button.addEventListener(
      "click",
      () => {

        setQRType(
          button.dataset.type
        );

      }
    );

  });


// ========================================
// INITIAL STORAGE
// ========================================

loadStorage();

updateTextCount();

setQRType("text");
// ========================================
// LUCHSHIY QR
// SCRIPT.JS — BLOCK 2
// QR DATA + GENERATION
// ========================================

function getQRData() {

  switch (state.currentType) {

    case "text": {

      const text =
        qrText?.value.trim();

      if (!text) {
        showToast(
          "Введите текст",
          "!"
        );
        return null;
      }

      return text;
    }


    case "url": {

      let url =
        qrUrl?.value.trim();

      if (!url) {
        showToast(
          "Введите ссылку",
          "!"
        );
        return null;
      }

      if (
        !/^https?:\/\//i.test(url)
      ) {
        url =
          "https://" + url;
      }

      return url;
    }


    case "phone": {

      const phone =
        qrPhone?.value.trim();

      if (!phone) {
        showToast(
          "Введите номер телефона",
          "!"
        );
        return null;
      }

      return `tel:${phone}`;
    }


    case "email": {

      const email =
        qrEmail?.value.trim();

      const subject =
        emailSubject?.value.trim();

      if (!email) {
        showToast(
          "Введите Email",
          "!"
        );
        return null;
      }

      let data =
        `mailto:${email}`;

      if (subject) {
        data +=
          `?subject=${encodeURIComponent(
            subject
          )}`;
      }

      return data;
    }


    case "contact": {

      const name =
        contactName?.value.trim();

      const phone =
        contactPhone?.value.trim();

      if (!name && !phone) {
        showToast(
          "Заполните контакт",
          "!"
        );
        return null;
      }

      return [
        "BEGIN:VCARD",
        "VERSION:3.0",
        `FN:${name || "Контакт"}`,
        `TEL:${phone || ""}`,
        "END:VCARD"
      ].join("\n");
    }


    case "wifi": {

      const name =
        wifiName?.value.trim();

      const password =
        wifiPassword?.value;

      const security =
        wifiSecurity?.value || "WPA";

      if (!name) {
        showToast(
          "Введите название Wi-Fi",
          "!"
        );
        return null;
      }

      const escapedName =
        escapeQRValue(name);

      const escapedPassword =
        escapeQRValue(password);

      return (
        `WIFI:T:${security};` +
        `S:${escapedName};` +
        `P:${escapedPassword};;`
      );
    }


    default:
      return null;
  }
}


// ========================================
// ESCAPE WI-FI DATA
// ========================================

function escapeQRValue(value) {

  return String(value || "")
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/:/g, "\\:");
}


// ========================================
// GENERATE QR
// ========================================

function generateQR() {

  const data =
    getQRData();

  if (!data) return;

  if (
    typeof QRCode ===
    "undefined"
  ) {
    showToast(
      "QR-модуль не загрузился",
      "!"
    );
    return;
  }

  state.currentData =
    data;

  qrCanvas.innerHTML = "";

  const size =
    Number(
      state.qrSettings.size
    );

  try {

    state.currentQR =
      new QRCode(
        qrCanvas,
        {
          text: data,

          width: size,

          height: size,

          colorDark:
            state.qrSettings
              .foreground,

          colorLight:
            state.qrSettings
              .background,

          correctLevel:
            QRCode.CorrectLevel.H
        }
      );

    qrResult?.classList.remove(
      "hidden"
    );

    addToHistory(data);

    showToast(
      "QR-код создан",
      "✓"
    );

    setTimeout(() => {

      qrResult?.scrollIntoView({
        behavior: "smooth",
        block: "center"
      });

    }, 80);

  } catch (error) {

    console.error(
      "QR generation error:",
      error
    );

    showToast(
      "Не удалось создать QR",
      "!"
    );
  }
}


// ========================================
// GENERATE BUTTON
// ========================================

generateButton?.addEventListener(
  "click",
  generateQR
);


// ========================================
// CLOSE RESULT
// ========================================

closeResult?.addEventListener(
  "click",
  () => {

    qrResult?.classList.add(
      "hidden"
    );

  }
);


// ========================================
// DOWNLOAD QR
// ========================================

function getQRImage() {

  if (!qrCanvas) {
    return null;
  }

  const canvas =
    qrCanvas.querySelector(
      "canvas"
    );

  if (canvas) {
    return canvas;
  }

  const image =
    qrCanvas.querySelector(
      "img"
    );

  return image || null;
}


$("#downloadQR")
  ?.addEventListener(
    "click",
    () => {

      const image =
        getQRImage();

      if (!image) {
        showToast(
          "Сначала создай QR-код",
          "!"
        );
        return;
      }

      let url = "";

      if (
        image instanceof HTMLCanvasElement
      ) {
        url =
          image.toDataURL(
            "image/png"
          );
      } else {
        url =
          image.src;
      }

      const link =
        document.createElement(
          "a"
        );

      link.href = url;

      link.download =
        `LUCHSHIY-QR-${Date.now()}.png`;

      document.body.appendChild(
        link
      );

      link.click();

      link.remove();

      showToast(
        "QR сохранён",
        "✓"
      );
    }
  );


// ========================================
// SHARE QR
// ========================================

$("#shareQR")
  ?.addEventListener(
    "click",
    async () => {

      const image =
        getQRImage();

      if (!image) {
        showToast(
          "Сначала создай QR-код",
          "!"
        );
        return;
      }

      try {

        if (
          navigator.share
        ) {

          if (
            image instanceof
            HTMLCanvasElement
          ) {

            image.toBlob(
              async blob => {

                const file =
                  new File(
                    [blob],
                    "LUCHSHIY-QR.png",
                    {
                      type:
                        "image/png"
                    }
                  );

                try {

                  await navigator.share({
                    title:
                      "LUCHSHIY QR",
                    text:
                      "Мой QR-код",
                    files:
                      [file]
                  });

                } catch {
                  return;
                }

              },
              "image/png"
            );

            return;
          }

          await navigator.share({
            title:
              "LUCHSHIY QR",
            text:
              state.currentData
          });

          return;
        }

        showToast(
          "Поделиться недоступно",
          "!"
        );

      } catch (error) {

        console.warn(
          "Share error:",
          error
        );

      }
    }
  );


// ========================================
// SAVE QR TO HISTORY
// ========================================

function addToHistory(data) {

  const type =
    state.currentType;

  state.history =
    state.history.filter(
      item =>
        item.data !== data
    );

  state.history.unshift({
    id:
      Date.now(),

    type:
      type,

    data:
      data,

    favorite:
      false
  });

  state.history =
    state.history.slice(
      0,
      30
    );

  saveHistory();
}


// ========================================
// SAVE HISTORY
// ========================================

function saveHistory() {

  localStorage.setItem(
    STORAGE.history,
    JSON.stringify(
      state.history
    )
  );

}


// ========================================
// SAVE FAVORITE
// ========================================

function saveFavorites() {

  localStorage.setItem(
    STORAGE.favorites,
    JSON.stringify(
      state.favorites
    )
  );

}


// ========================================
// FAVORITE CHECK
// ========================================

function isFavorite(data) {

  return state.favorites.some(
    item =>
      item.data === data
  );

}


// ========================================
// ADD FAVORITE
// ========================================

function addFavorite(data) {

  if (!data) return;

  if (
    isFavorite(data)
  ) {

    showToast(
      "Уже в избранном",
      "★"
    );

    return;
  }

  state.favorites.push({

    id:
      Date.now(),

    type:
      state.currentType,

    data:
      data

  });

  saveFavorites();

  showToast(
    "Добавлено в избранное",
    "★"
  );

}


// ========================================
// REMOVE FAVORITE
// ========================================

function removeFavorite(data) {

  state.favorites =
    state.favorites.filter(
      item =>
        item.data !== data
    );

  saveFavorites();

}


// ========================================
// QR RESULT DOUBLE CHECK
// ========================================

function hasQRResult() {

  return (
    qrCanvas &&
    qrCanvas.children.length > 0
  );

}
// ========================================
// LUCHSHIY QR
// SCRIPT.JS — BLOCK 3
// HISTORY + FAVORITES + CUSTOMIZE
// ========================================

// ========================================
// HISTORY RENDER
// ========================================

const historyList =
  $("#historyList");

const emptyHistory =
  $("#emptyHistory");

const favoritesList =
  $("#favoritesList");

const emptyFavorites =
  $("#emptyFavorites");


function getTypeName(type) {

  const names = {

    text: "Текст",

    url: "Ссылка",

    wifi: "Wi-Fi",

    contact: "Контакт",

    email: "Email",

    phone: "Телефон"

  };

  return names[type] ||
    "QR-код";
}


function renderHistory() {

  if (!historyList) {
    return;
  }

  historyList.innerHTML = "";

  if (
    state.history.length === 0
  ) {

    emptyHistory
      ?.classList.remove(
        "hidden"
      );

    return;
  }

  emptyHistory
    ?.classList.add(
      "hidden"
    );


  state.history.forEach(item => {

    const button =
      document.createElement(
        "button"
      );

    button.className =
      "history-item";

    button.dataset.id =
      item.id;

    button.innerHTML = `

      <div class="history-content">

        <span class="history-original">
          ${escapeHTML(
            item.data
          )}
        </span>

        <span class="history-translation">
          ${getTypeName(
            item.type
          )}
        </span>

      </div>

      <span class="history-arrow">
        →
      </span>

    `;

    historyList.appendChild(
      button
    );

  });

}


// ========================================
// HISTORY CLICK
// ========================================

historyList?.addEventListener(
  "click",
  event => {

    const item =
      event.target.closest(
        ".history-item"
      );

    if (!item) {
      return;
    }

    const id =
      Number(
        item.dataset.id
      );

    const historyItem =
      state.history.find(
        entry =>
          entry.id === id
      );

    if (!historyItem) {
      return;
    }

    state.currentType =
      historyItem.type;

    setQRType(
      historyItem.type
    );

    fillTypeFromHistory(
      historyItem
    );

    showToast(
      "QR-код загружен",
      "✓"
    );

  }
);


// ========================================
// FILL HISTORY DATA
// ========================================

function fillTypeFromHistory(
  item
) {

  const data =
    item.data || "";

  switch (item.type) {

    case "text":

      if (qrText) {
        qrText.value =
          data;
      }

      updateTextCount();

      break;


    case "url":

      if (qrUrl) {
        qrUrl.value =
          data;
      }

      break;


    case "phone":

      if (qrPhone) {
        qrPhone.value =
          data.replace(
            /^tel:/i,
            ""
          );
      }

      break;


    case "email": {

      const clean =
        data.replace(
          /^mailto:/i,
          ""
        );

      const parts =
        clean.split("?");

      if (qrEmail) {
        qrEmail.value =
          parts[0];
      }

      if (emailSubject) {

        const params =
          new URLSearchParams(
            parts[1] || ""
          );

        emailSubject.value =
          params.get(
            "subject"
          ) || "";

      }

      break;
    }


    case "wifi": {

      const match =
        data.match(
          /WIFI:T:([^;]*);S:([^;]*);P:([^;]*);/
        );

      if (match) {

        if (wifiSecurity) {
          wifiSecurity.value =
            match[1];
        }

        if (wifiName) {
          wifiName.value =
            match[2];
        }

        if (wifiPassword) {
          wifiPassword.value =
            match[3];
        }

      }

      break;
    }


    case "contact": {

      const name =
        data.match(
          /FN:(.*)/
        );

      const phone =
        data.match(
          /TEL:(.*)/
        );

      if (contactName) {
        contactName.value =
          name
            ? name[1]
            : "";
      }

      if (contactPhone) {
        contactPhone.value =
          phone
            ? phone[1]
            : "";
      }

      break;
    }

  }

}


// ========================================
// FAVORITES RENDER
// ========================================

function renderFavorites() {

  if (!favoritesList) {
    return;
  }

  favoritesList.innerHTML = "";

  if (
    state.favorites.length === 0
  ) {

    emptyFavorites
      ?.classList.remove(
        "hidden"
      );

    return;
  }

  emptyFavorites
    ?.classList.add(
      "hidden"
    );


  state.favorites.forEach(item => {

    const button =
      document.createElement(
        "button"
      );

    button.className =
      "favorite-item";

    button.dataset.id =
      item.id;

    button.innerHTML = `

      <div>

        <strong>
          ${escapeHTML(
            item.data
          )}
        </strong>

        <span>
          ${getTypeName(
            item.type
          )}
        </span>

      </div>

      <span>
        ★
      </span>

    `;

    favoritesList.appendChild(
      button
    );

  });

}


// ========================================
// FAVORITES CLICK
// ========================================

favoritesList?.addEventListener(
  "click",
  event => {

    const item =
      event.target.closest(
        ".favorite-item"
      );

    if (!item) {
      return;
    }

    const id =
      Number(
        item.dataset.id
      );

    const favorite =
      state.favorites.find(
        entry =>
          entry.id === id
      );

    if (!favorite) {
      return;
    }

    state.currentType =
      favorite.type;

    setQRType(
      favorite.type
    );

    fillTypeFromHistory(
      favorite
    );

    showToast(
      "Избранный QR загружен",
      "★"
    );

  }
);


// ========================================
// SAVE CURRENT QR
// ========================================

function favoriteCurrentQR() {

  if (!state.currentData) {

    showToast(
      "Сначала создай QR-код",
      "!"
    );

    return;
  }

  if (
    isFavorite(
      state.currentData
    )
  ) {

    removeFavorite(
      state.currentData
    );

    renderFavorites();

    showToast(
      "Удалено из избранного",
      "−"
    );

    return;
  }

  addFavorite(
    state.currentData
  );

  renderFavorites();

}


// ========================================
// CUSTOMIZE DOM
// ========================================

const customizeSection =
  $("#customizeSection");

const qrSize =
  $("#qrSize");

const qrForeground =
  $("#qrForeground");

const qrBackground =
  $("#qrBackground");

const qrMargin =
  $("#qrMargin");

const applyCustomize =
  $("#applyCustomize");

const closeCustomize =
  $("#closeCustomize");


// ========================================
// LOAD QR SETTINGS
// ========================================

function loadQRSettings() {

  if (qrSize) {

    qrSize.value =
      String(
        state.qrSettings.size
      );

  }

  if (qrForeground) {

    qrForeground.value =
      state.qrSettings
        .foreground;

  }

  if (qrBackground) {

    qrBackground.value =
      state.qrSettings
        .background;

  }

  if (qrMargin) {

    qrMargin.value =
      String(
        state.qrSettings.margin
      );

  }

}


// ========================================
// OPEN CUSTOMIZE
// ========================================

function openCustomize() {

  loadQRSettings();

  customizeSection
    ?.classList.remove(
      "hidden"
    );

  customizeSection
    ?.scrollIntoView({
      behavior: "smooth",
      block: "center"
    });

}


// ========================================
// CLOSE CUSTOMIZE
// ========================================

function hideCustomize() {

  customizeSection
    ?.classList.add(
      "hidden"
    );

}


// ========================================
// APPLY CUSTOMIZE
// ========================================

applyCustomize?.addEventListener(
  "click",
  () => {

    state.qrSettings.size =
      Number(
        qrSize?.value || 512
      );

    state.qrSettings
      .foreground =
        qrForeground?.value ||
        "#000000";

    state.qrSettings
      .background =
        qrBackground?.value ||
        "#ffffff";

    state.qrSettings.margin =
      Number(
        qrMargin?.value || 2
      );

    saveSettings();

    hideCustomize();

    showToast(
      "Дизайн сохранён",
      "✓"
    );

  }
);


// ========================================
// CUSTOMIZE BUTTONS
// ========================================

$("#quickCustomize")
  ?.addEventListener(
    "click",
    openCustomize
  );

closeCustomize?.addEventListener(
  "click",
  hideCustomize
);


// ========================================
// QUICK CREATE
// ========================================

$("#quickCreate")
  ?.addEventListener(
    "click",
    () => {

      qrText?.focus();

      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });

    }
  );


// ========================================
// QUICK HISTORY
// ========================================

$("#quickHistory")
  ?.addEventListener(
    "click",
    () => {

      const section =
        $("#historySection");

      section
        ?.classList.remove(
          "hidden"
        );

      section
        ?.scrollIntoView({
          behavior: "smooth",
          block: "start"
        });

    }
  );


// ========================================
// QUICK SCAN
// ========================================

$("#quickScan")
  ?.addEventListener(
    "click",
    () => {

      $("#scannerSection")
        ?.classList.remove(
          "hidden"
        );

      $("#scannerSection")
        ?.scrollIntoView({
          behavior: "smooth",
          block: "start"
        });

    }
  );


// ========================================
// TOOLS BUTTONS
// ========================================

$("#historyButton")
  ?.addEventListener(
    "click",
    () => {

      $("#historySection")
        ?.classList.toggle(
          "hidden"
        );

      renderHistory();

    }
  );


$("#favoritesButton")
  ?.addEventListener(
    "click",
    () => {

      $("#favoritesSection")
        ?.classList.toggle(
          "hidden"
        );

      renderFavorites();

    }
  );


$("#scanQRButton")
  ?.addEventListener(
    "click",
    () => {

      $("#scannerSection")
        ?.classList.remove(
          "hidden"
        );

      $("#scannerSection")
        ?.scrollIntoView({
          behavior: "smooth",
          block: "start"
        });

    }
  );


// ========================================
// CLEAR HISTORY
// ========================================

$("#clearHistory")
  ?.addEventListener(
    "click",
    () => {

      state.history = [];

      saveHistory();

      renderHistory();

      showToast(
        "История очищена",
        "✓"
      );

    }
  );


// ========================================
// INITIAL RENDER
// ========================================

renderHistory();

renderFavorites();

loadQRSettings();
/* ========================================
   LUCHSHIY QR
   SCRIPT.JS — BLOCK 4
   CAMERA SCANNER
   ======================================== */

const scannerSection =
  $("#scannerSection");

const scannerVideo =
  $("#scannerVideo");

const scannerCanvas =
  $("#scannerCanvas");

const scannerPlaceholder =
  $("#scannerPlaceholder");

const scanResult =
  $("#scanResult");

const scanResultText =
  $("#scanResultText");

const startScanner =
  $("#startScanner");

const closeScanner =
  $("#closeScanner");

const copyScanResult =
  $("#copyScanResult");

const openScanResult =
  $("#openScanResult");

const imageInput =
  $("#imageInput");

let scannerStream = null;

let scannerActive = false;

let scannerAnimation = null;


/* ========================================
   CHECK CAMERA
   ======================================== */

function cameraSupported() {

  return Boolean(
    navigator.mediaDevices &&
    navigator.mediaDevices.getUserMedia
  );

}


/* ========================================
   START CAMERA
   ======================================== */

async function startCameraScanner() {

  if (!cameraSupported()) {

    showToast(
      "Камера недоступна",
      "!"
    );

    return;

  }

  try {

    stopCameraScanner();

    scannerStream =
      await navigator.mediaDevices
        .getUserMedia({

          video: {
            facingMode: {
              ideal: "environment"
            },

            width: {
              ideal: 1280
            },

            height: {
              ideal: 720
            }

          },

          audio: false

        });


    scannerVideo.srcObject =
      scannerStream;

    scannerVideo.muted = true;

    scannerVideo.playsInline = true;

    await scannerVideo.play();

    scannerActive = true;

    scannerPlaceholder
      ?.classList.add(
        "hidden"
      );

    startScanner.textContent =
      "Сканер работает";

    showToast(
      "Наведи камеру на QR",
      "◉"
    );

    scanCameraFrame();

  } catch (error) {

    console.error(
      "Camera error:",
      error
    );

    showToast(
      "Не удалось открыть камеру",
      "!"
    );

  }

}


/* ========================================
   STOP CAMERA
   ======================================== */

function stopCameraScanner() {

  scannerActive = false;

  if (scannerAnimation) {

    cancelAnimationFrame(
      scannerAnimation
    );

    scannerAnimation = null;

  }


  if (scannerStream) {

    scannerStream
      .getTracks()
      .forEach(track => {
        track.stop();
      });

    scannerStream = null;

  }


  if (scannerVideo) {

    scannerVideo.pause();

    scannerVideo.srcObject =
      null;

  }


  if (startScanner) {

    startScanner.textContent =
      "Запустить камеру";

  }

}


/* ========================================
   CAMERA FRAME
   ======================================== */

function scanCameraFrame() {

  if (!scannerActive) {
    return;
  }

  if (
    !scannerVideo ||
    scannerVideo.readyState <
      2
  ) {

    scannerAnimation =
      requestAnimationFrame(
        scanCameraFrame
      );

    return;

  }


  const width =
    scannerVideo.videoWidth;

  const height =
    scannerVideo.videoHeight;


  if (!width || !height) {

    scannerAnimation =
      requestAnimationFrame(
        scanCameraFrame
      );

    return;

  }


  scannerCanvas.width =
    width;

  scannerCanvas.height =
    height;


  const context =
    scannerCanvas.getContext(
      "2d",
      {
        willReadFrequently: true
      }
    );


  context.drawImage(
    scannerVideo,
    0,
    0,
    width,
    height
  );


  if (
    "BarcodeDetector"
    in window
  ) {

    detectQRCode();

  }


  scannerAnimation =
    requestAnimationFrame(
      scanCameraFrame
    );

}


/* ========================================
   BARCODE DETECTOR
   ======================================== */

async function detectQRCode() {

  if (!scannerActive) {
    return;
  }

  if (
    !("BarcodeDetector" in window)
  ) {

    return;

  }


  try {

    if (
      !window.qrDetector
    ) {

      window.qrDetector =
        new BarcodeDetector({
          formats: ["qr_code"]
        });

    }


    const codes =
      await window.qrDetector
        .detect(
          scannerVideo
        );


    if (
      codes &&
      codes.length > 0
    ) {

      const value =
        codes[0].rawValue;

      if (value) {

        handleScanResult(
          value
        );

      }

    }

  } catch (error) {

    // Камера продолжает работать.
    // Некоторые браузеры могут
    // временно не поддерживать
    // BarcodeDetector.

  }

}


/* ========================================
   SCAN RESULT
   ======================================== */

function handleScanResult(value) {

  if (!value) {
    return;
  }

  stopCameraScanner();

  scannerActive = false;

  if (scanResultText) {

    scanResultText.textContent =
      value;

  }

  scanResult
    ?.classList.remove(
      "hidden"
    );

  showToast(
    "QR-код найден",
    "✓"
  );

  saveScanHistory(
    value
  );

}


/* ========================================
   SCAN HISTORY
   ======================================== */

function saveScanHistory(value) {

  const item = {

    id:
      Date.now(),

    type:
      "scan",

    data:
      value

  };


  const scans =
    JSON.parse(
      localStorage.getItem(
        "luchshiyQRScans"
      ) || "[]"
    );


  const filtered =
    scans.filter(
      entry =>
        entry.data !== value
    );


  filtered.unshift(
    item
  );


  localStorage.setItem(
    "luchshiyQRScans",
    JSON.stringify(
      filtered.slice(0, 30)
    )
  );

}


/* ========================================
   START BUTTON
   ======================================== */

startScanner?.addEventListener(
  "click",
  () => {

    if (scannerActive) {

      stopCameraScanner();

      return;

    }

    startCameraScanner();

  }
);


/* ========================================
   CLOSE SCANNER
   ======================================== */

closeScanner?.addEventListener(
  "click",
  () => {

    stopCameraScanner();

    scannerSection
      ?.classList.add(
        "hidden"
      );

    scanResult
      ?.classList.add(
        "hidden"
      );

  }
);


/* ========================================
   COPY SCANNED RESULT
   ======================================== */

copyScanResult?.addEventListener(
  "click",
  async () => {

    const value =
      scanResultText?.textContent;

    if (!value) {
      return;
    }

    try {

      await navigator.clipboard
        .writeText(value);

      showToast(
        "Результат скопирован",
        "✓"
      );

    } catch {

      showToast(
        "Не удалось скопировать",
        "!"
      );

    }

  }
);


/* ========================================
   OPEN SCANNED LINK
   ======================================== */

openScanResult?.addEventListener(
  "click",
  () => {

    const value =
      scanResultText?.textContent
        ?.trim();

    if (!value) {
      return;
    }


    if (
      /^https?:\/\//i.test(value)
    ) {

      window.open(
        value,
        "_blank",
        "noopener,noreferrer"
      );

      return;

    }


    if (
      /^www\./i.test(value)
    ) {

      window.open(
        `https://${value}`,
        "_blank",
        "noopener,noreferrer"
      );

      return;

    }


    showToast(
      "Это не ссылка",
      "!"
    );

  }
);


/* ========================================
   IMAGE SCANNER
   ======================================== */

function openImageScanner() {

  imageInput?.click();

}


imageInput?.addEventListener(
  "change",
  async event => {

    const file =
      event.target.files?.[0];

    if (!file) {
      return;
    }


    if (
      !("BarcodeDetector" in window)
    ) {

      showToast(
        "Сканирование изображения не поддерживается",
        "!"
      );

      imageInput.value = "";

      return;

    }


    try {

      const detector =
        new BarcodeDetector({
          formats: ["qr_code"]
        });


      const bitmap =
        await createImageBitmap(
          file
        );


      const codes =
        await detector.detect(
          bitmap
        );


      bitmap.close();


      if (
        !codes ||
        codes.length === 0
      ) {

        showToast(
          "QR-код не найден",
          "!"
        );

        return;

      }


      handleScanResult(
        codes[0].rawValue
      );

    } catch (error) {

      console.error(
        "Image scan error:",
        error
      );

      showToast(
        "Не удалось прочитать изображение",
        "!"
      );

    } finally {

      imageInput.value = "";

    }

  }
);


/* ========================================
   IMAGE SCANNER FROM SCAN BUTTON
   ======================================== */

const scannerBox =
  $(".scanner-box");

scannerBox?.addEventListener(
  "dblclick",
  openImageScanner
);


/* ========================================
   STOP CAMERA WHEN PAGE HIDDEN
   ======================================== */

document.addEventListener(
  "visibilitychange",
  () => {

    if (
      document.hidden &&
      scannerActive
    ) {

      stopCameraScanner();

    }

  }
);


/* ========================================
   STOP CAMERA BEFORE PAGE CLOSE
   ======================================== */

window.addEventListener(
  "beforeunload",
  () => {

    stopCameraScanner();

  }
);
/* ========================================
   LUCHSHIY QR
   SCRIPT.JS — BLOCK 5
   SETTINGS + FINALIZATION
   ======================================== */


/* ========================================
   SETTINGS ELEMENTS
   ======================================== */

const settingsModal =
  $("#settingsModal");

const settingsOverlay =
  $("#settingsOverlay");

const settingsClose =
  $("#settingsClose");

const clearAllData =
  $("#clearAllData");

const confirmModal =
  $("#confirmModal");

const confirmOverlay =
  $("#confirmOverlay");

const cancelConfirm =
  $("#cancelConfirm");

const confirmClear =
  $("#confirmClear");

const appToast =
  $("#appToast");

const appToastIcon =
  $("#appToastIcon");

const appToastText =
  $("#appToastText");


/* ========================================
   APP TOAST
   ======================================== */

function appMessage(
  message,
  icon = "✓"
) {

  if (
    appToast &&
    appToastText
  ) {

    appToastText.textContent =
      message;

    if (appToastIcon) {

      appToastIcon.textContent =
        icon;

    }

    appToast
      .classList.add(
        "show"
      );


    clearTimeout(
      window.appToastTimer
    );


    window.appToastTimer =
      setTimeout(
        () => {

          appToast
            .classList.remove(
              "show"
            );

        },
        2800
      );

    return;

  }


  showToast(
    message,
    icon
  );

}


/* ========================================
   OPEN SETTINGS
   ======================================== */

function openSettings() {

  settingsModal
    ?.classList.remove(
      "hidden"
    );

}


/* ========================================
   CLOSE SETTINGS
   ======================================== */

function closeSettings() {

  settingsModal
    ?.classList.add(
      "hidden"
    );

}


$("#settingsButton")
  ?.addEventListener(
    "click",
    openSettings
  );


settingsClose
  ?.addEventListener(
    "click",
    closeSettings
  );


settingsOverlay
  ?.addEventListener(
    "click",
    closeSettings
  );


/* ========================================
   ESC KEY
   ======================================== */

document.addEventListener(
  "keydown",
  event => {

    if (
      event.key !== "Escape"
    ) {
      return;
    }


    closeSettings();

    confirmModal
      ?.classList.add(
        "hidden"
      );

  }
);


/* ========================================
   THEME
   ======================================== */

const themeButtons =
  $$("[data-theme]");


function setTheme(theme) {

  if (
    theme === "light"
  ) {

    document.body
      .classList.add(
        "theme-light"
      );

  } else {

    document.body
      .classList.remove(
        "theme-light"
      );

  }


  localStorage.setItem(
    "luchshiyQRTheme",
    theme
  );


  themeButtons.forEach(
    button => {

      button.classList.toggle(
        "active",
        button.dataset.theme ===
          theme
      );

    }
  );

}


themeButtons.forEach(
  button => {

    button.addEventListener(
      "click",
      () => {

        setTheme(
          button.dataset.theme
        );

      }
    );

  }
);


/* ========================================
   LOAD THEME
   ======================================== */

function loadTheme() {

  const saved =
    localStorage.getItem(
      "luchshiyQRTheme"
    ) || "dark";

  setTheme(saved);

}


loadTheme();


/* ========================================
   CONFIRM CLEAR DATA
   ======================================== */

function openClearConfirm() {

  confirmModal
    ?.classList.remove(
      "hidden"
    );

}


function closeClearConfirm() {

  confirmModal
    ?.classList.add(
      "hidden"
    );

}


clearAllData
  ?.addEventListener(
    "click",
    openClearConfirm
  );


cancelConfirm
  ?.addEventListener(
    "click",
    closeClearConfirm
  );


confirmOverlay
  ?.addEventListener(
    "click",
    closeClearConfirm
  );


/* ========================================
   CLEAR EVERYTHING
   ======================================== */

confirmClear
  ?.addEventListener(
    "click",
    () => {

      localStorage.removeItem(
        STORAGE.history
      );

      localStorage.removeItem(
        STORAGE.favorites
      );

      localStorage.removeItem(
        STORAGE.settings
      );

      localStorage.removeItem(
        "luchshiyQRScans"
      );


      state.history = [];

      state.favorites = [];


      loadStorage();

      renderHistory();

      renderFavorites();


      closeClearConfirm();

      closeSettings();


      appMessage(
        "Все данные удалены",
        "✓"
      );

    }
  );


/* ========================================
   ONLINE / OFFLINE
   ======================================== */

const offlineBanner =
  $("#offlineBanner");


function updateConnectionStatus() {

  if (!offlineBanner) {
    return;
  }


  offlineBanner.classList.toggle(
    "show",
    !navigator.onLine
  );

}


window.addEventListener(
  "online",
  () => {

    updateConnectionStatus();

    appMessage(
      "Соединение восстановлено",
      "✓"
    );

  }
);


window.addEventListener(
  "offline",
  () => {

    updateConnectionStatus();

    appMessage(
      "Вы работаете офлайн",
      "!"
    );

  }
);


updateConnectionStatus();


/* ========================================
   INPUT VALIDATION
   ======================================== */

function markInvalid(input) {

  if (!input) {
    return;
  }

  input.classList.add(
    "input-error"
  );


  setTimeout(
    () => {

      input.classList.remove(
        "input-error"
      );

    },
    1500
  );

}


function validateCurrentType() {

  const type =
    state.currentType;

  const data =
    getQRData();


  if (
    !data ||
    !data.trim()
  ) {

    const input =
      inputAreas[type];

    markInvalid(input);

    appMessage(
      "Заполни поле",
      "!"
    );

    return false;

  }


  return true;

}


/* ========================================
   GENERATE VALIDATION
   ======================================== */

generateButton
  ?.addEventListener(
    "click",
    event => {

      if (
        !validateCurrentType()
      ) {

        event.stopImmediatePropagation();

      }

    },
    true
  );


/* ========================================
   RESET FORM
   ======================================== */

function resetForm() {

  $$("#generatorSection input")
    .forEach(
      input => {

        input.value = "";

      }
    );


  if (qrText) {

    qrText.value = "";

  }


  updateTextCount();

  setQRType("text");


  qrResult
    ?.classList.add(
      "hidden"
    );

}


window.resetLUCHSHIYQR =
  resetForm;


/* ========================================
   APP START
   ======================================== */

function initializeApp() {

  loadStorage();

  loadQRSettings();

  loadTheme();

  renderHistory();

  renderFavorites();

  updateTextCount();

  updateConnectionStatus();


  if (qrResult) {

    qrResult
      .classList.add(
        "hidden"
      );

  }


  console.log(
    "LUCHSHIY QR initialized"
  );

}


initializeApp();


/* ========================================
   VERSION
   ======================================== */

window.LUCHSHIY_QR_VERSION =
  "1.0.0";


console.log(
  "LUCHSHIY QR v1.0.0"
);

console.log(
  "Creator: LUCHSHIY"
);


/* ========================================
   FINAL SAFETY
   ======================================== */

window.addEventListener(
  "error",
  event => {

    console.error(
      "LUCHSHIY QR error:",
      event.error
    );

  }
);


/* ========================================
   END OF SCRIPT
   ======================================== */