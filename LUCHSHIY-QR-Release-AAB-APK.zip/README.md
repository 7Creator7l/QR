# LUCHSHIY QR — Release APK + AAB

Готовый GitHub Actions проект для сборки LUCHSHIY QR.

После запуска workflow:
- `LUCHSHIY-QR-release.apk`
- `LUCHSHIY-QR-release.aab`

Для финальной публикации в Google Play нужен release keystore.
GitHub Secrets:
- ANDROID_KEYSTORE_BASE64
- KEYSTORE_PASSWORD
- KEY_ALIAS
- KEY_PASSWORD

Не добавляй keystore и пароли прямо в репозиторий.
