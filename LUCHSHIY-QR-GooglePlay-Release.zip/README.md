# LUCHSHIY QR — Google Play Release

Этот проект подготовлен для GitHub Actions и собирает:

- `LUCHSHIY-QR-release.aab` — основной файл для Google Play
- `LUCHSHIY-QR-release.apk` — для тестирования

Package ID: `com.luchshiy.qr`
Version: `1.0.0`
Target SDK: 35

## Перед сборкой

В GitHub → Settings → Secrets and variables → Actions добавь:

1. `ANDROID_KEYSTORE_BASE64`
2. `KEYSTORE_PASSWORD`
3. `KEY_ALIAS`
4. `KEY_PASSWORD`

`ANDROID_KEYSTORE_BASE64` — это твой upload/release keystore, закодированный в Base64.

Не добавляй `.jks` и пароли прямо в репозиторий.

## Сборка

GitHub → Actions → **Build LUCHSHIY QR for Google Play** → **Run workflow**.

После успешной сборки:
Actions → запуск → Artifacts → `LUCHSHIY-QR-GooglePlay-Release`.

Для Google Play нужен файл `.aab`. ZIP из Artifacts сначала распакуй.
