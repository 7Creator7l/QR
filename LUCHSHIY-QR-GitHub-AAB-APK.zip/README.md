# LUCHSHIY QR

Android-ready version of the LUCHSHIY QR web app.

## Build APK/AAB on GitHub

1. Create a GitHub repository.
2. Upload all files from this folder.
3. Open **Actions** → **Build Android APK and AAB**.
4. Press **Run workflow**.
5. After the build finishes, open the workflow run and download the artifact **luchshiy-qr-android**.

The workflow creates:
- `app-debug.apk` — test APK
- `app-release-unsigned.apk` — release APK without signing
- `app-release.aab` — release AAB without signing

For Google Play, the AAB must be signed with your own release key before publishing.
